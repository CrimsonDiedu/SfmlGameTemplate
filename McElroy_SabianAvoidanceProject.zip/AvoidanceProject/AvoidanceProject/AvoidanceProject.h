#pragma once


#include "stdafx.h"


using namespace System;
using std::cout;

namespace APHeader {

}


