#pragma once

#include "Base.h"


class Item: public Base
{
public:
	Item();
	Item(int t);
	~Item();
	void Update();

private:
	int seq;
};

