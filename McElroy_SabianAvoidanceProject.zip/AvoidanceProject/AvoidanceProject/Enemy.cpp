#pragma once

#include "stdafx.h"
#include "Enemy.h"

Enemy::Enemy()
{
	active = true;
	speed = (rand() % 7) + 1;
}

Enemy::~Enemy()
{
}

void Enemy::Update() {
	type = 2;

	if (GetCol() == ConsoleColor::DarkGreen) {
		if (seq > 10) {
			seq = 0;
		}elseif(seq == 10) {
			SetCol(ConsoleColor::Green);
		}
	}
}
void Enemy::UpDifficulty()
{
	chance++;
}
//vector<Record> records;
//Record R;
//Records.push_back(R);
//vector<Record>::iterator riter
//for(riter = records.begin(); riter

void Enemy::Move(int px, int py) {
				if (active)
				{
					xp = x;
					yp = y;

					delay++;
					Update();
					int dis = (int)sqrt((x - px) *(x - px) + (y - py)*(y - py)), spd = 1;
					/**/

					if (dis > Console::WindowWidth() *.52) {
						spd = -spd;
					}

					if (delay % speed == 0)
					{
						if (x < px || ODDS chance == 0) {

							x += spd;
						}
						else if (x > px || ODDS chance == 0) {
							x -= spd;
						}

						if (y < py || ODDS chance == 0) {
							y += spd;
						}
						else if (y > py || ODDS chance == 0) {
							y -= spd;
						}
					}
				}
			}

