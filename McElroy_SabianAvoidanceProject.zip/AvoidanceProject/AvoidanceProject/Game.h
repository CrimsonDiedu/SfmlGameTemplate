#pragma once 
#include <string>

class Game
{
public:
	Game();
	~Game();
	bool running;
	int size,score;
	std::vector<Base*> Objects;
	std::vector<std::string> Entries;
	std::string Initials;
	int Play();
	void IncreaseDifficulty();
	char firsti, lasti;
	void LoadScores();
	void ShowScores();
private:
	
	void Init();
	void Update();
	void Render();
	void Start();
	void End();
	void SaveScores();
	
};
