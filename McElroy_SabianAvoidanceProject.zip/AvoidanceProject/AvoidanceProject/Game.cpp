
#include "stdafx.h"
#include "Game.h"
#include <fstream>

void Game::SaveScores() {
	ofstream ofile;
	ofile.open("scores.txt");
	
	string entry =Initials + '\t' +std::to_string(score) + '\n';
	 Entries.push_back(entry);
	 for (unsigned int i = 0; i < Entries.size(); i++) {
		 ofile << Entries[i] << '\n';
	 }
	 ofile.close();
}

void Game::LoadScores() {
	ifstream ifile;
	ifile.open("scores.txt");
	if (ifile.is_open())
	{
		string line;
		while (getline(ifile, line))
		{
			Entries.push_back(line);
		};
	}
}

void Game::ShowScores() {
	
	for (unsigned int i = 0; i < Entries.size(); i++) {
		cout << Entries[i].c_str()<<'\n';

	}
}
Game::Game()
{
	size = 30;

}

Game::~Game()
{

}



void Game::Update() {
	Base *p = Objects[0], *q;
	p->Update();
	p->SetSym('@');
	
	int xx = p->GetX();
	int yy = p->GetY();

	for (unsigned int i = 1; i < Objects.size(); i++) {
		Objects[i]->Move(xx, yy);

		Objects[i]->Update();
	}

#pragma region CollisionLogic
	/*
	The existing objects will never "die", however, they follow these rules:
	If a player touches an enemy, that enemy will teleport to a new location, while the player loses one health point.
	If an enemy touches another enemy, the first enemy will teleport to a new location, becoming inactive.
	If a player touches a coin, that coin will teleport to a new location, giving the player 50 score points, and increasing the difficulty.
	If a player touches a heart pickup, that heart will teleport to a new location, giving the player 3 health points.
	*/
	for (unsigned int i = 0; i < Objects.size(); i++) {
		int x1 = Objects[i]->GetX(),
			y1 = Objects[i]->GetY();
		for (unsigned int j = 0; j < Objects.size(); j++) {
			int x2 = Objects[j]->GetX(),
				y2 = Objects[j]->GetY();
			if (i != j) {//if i is not j (So it doesnt try to compare to itself).
				if (x1 == x2 && y1 == y2) {
					//i reacts to j.

					p = Objects[i];
					q = Objects[j];
					int e = p->type, f = q->type;
					if (e != 0) {
						p->interacted = true;
						if (e == 1) {//if i is player

							if (f == 2) {//if j is enemy
								if (q->active)
								{
									p->Hurt();
									p->SetCol(ConsoleColor::DarkBlue);
									q->Rpos();
									q->SetCol(ConsoleColor::DarkGreen);
									q->active = false;
								}
							}
							elseif(f == 3) {//if j is coin
								p->AddPoints(10);
								IncreaseDifficulty();
								q->Rpos();
							}elseif(f == 4) {//if j is Heart Pickup.
								p->Heal(3);
								IncreaseDifficulty();
								q->Rpos();
							}
						}
						else if (e == 2 && f == 2) {//if two enemies intersect
							q->Rpos();
						}
					}
				}
			}
		}

	}
#pragma endregion

#pragma region GameOver



	if (!(Objects[0]->Alive())) {
		running = false;
	}
#pragma endregion
}

void Game::Render() {
	for (unsigned int i = 0; i < Objects.size(); i++) {//int i = Objects.size() - 1; i >= 0; i--
		Objects[i]->Render();
	}
	Base p = (*Objects[0]);
	Console::SetCursorPosition(1, 1);
	Console::ForegroundColor(ConsoleColor::White);
	if (p.GetScore() > score) { score++; }
	cout << "Hp: " << p.GetHP() << "     Score: " << score << "              ";
	for (int i = 0; i < Console::WindowWidth(); i++)
	{
		Console::SetCursorPosition(i, 3);
		cout << '_';
	}
}
//vector<Record> records;
//Record R;
//Records.push_back(R);
//vector<Record>::iterator riter
//for(riter = records.begin(); riter != records.end; riter++){}

//fstream ffilestr;
//ifstream || ofstream
//ffilestr.open("filename.txt",ios_base::cannotread.exe | ios::in);
//if(ffilestr.is_open())
//{
//ffilestr.seek(0,ios_base::eof())
//seek__ moves filepointer
//tell__ gives bytes
//		ffilestr.read(&record[0], #ofbytes);	
//		ffilestr.write(char *, 

 void Game::Start() {
	running = true;
	score = 0;

	Objects.push_back(new Player());
	for (int i = 0; i < rand() % 6; i++) {
		Base* o = new Item(3); 
		Objects.push_back(o);
	}
	

/*
#pragma region Superloop!
	int i;
	for (i = 1; i < size - 4; i++) {
		Objects[i] = new Enemy;
		Objects[i]->SetCol(ConsoleColor::Green);
	}
	for (i = i; i < size - 1; i++) {
		//Objects[i] = new Coin;
		Objects[i]->SetCol(ConsoleColor::Yellow);
	}
	for (i = i; i < size; i++) {
		//Objects[i] = new Heart();
		Objects[i]->SetCol(ConsoleColor::Red);
	}

#pragma endregion
*/

	int x, y, speed;

	for (unsigned int i = 0; i < Objects.size(); i++) {
		x = rand() % Console::WindowWidth();
		y = rand() % Console::WindowHeight();
		speed = (rand() % 7) + 3;
		//last err
		Objects[i]->SetObj(x, y, speed);
	}
	x = Objects[0]->GetX();
	y = Objects[0]->GetY();
	speed = 3;
	Objects[0]->SetCol(ConsoleColor::Cyan);
	Objects[0]->SetObj(x, y, speed);
}
void Game::End() {//end the game, while deleting player and enemy addresses
	for (unsigned int i = 0; i < Objects.size(); i++) {
		delete Objects[i];
	}
	//delete[] Objects;
}

int Game::Play() {//initialize the game(new), run until finished, and end the game(delete)
	Init();
	Start();
	while (running)
	{
		//Console::Clear(); Sleep(100);
		//Console::Clear();

		Update();
		Render();
		Sleep(10);
	}
	int s = Objects[0]->GetScore();
	SaveScores();
	End();
	return s;

}

/**/
void Game::IncreaseDifficulty() {
	int times = rand() % (size / 2), out = 0, inc = ODDS 6;
	Base O;
	while (times > 0) {
		if ((int)Objects.size() < size)
		{
			if (ODDS 5 == 0) {
				Enemy *o = new Enemy();
				o->active = true;
				Objects.push_back(o);
			}
			if (ODDS 20 == 0) {
				Item *o = new Item(4);
				o->active = true;
				Objects.push_back(o);
			}
			if (ODDS 10 == 0) {
				Item *o = new Item(3);
				o->active = true;
				Objects.push_back(o);
			}
		}
		for (unsigned int i = 1; i < Objects.size(); i++) {
			O = (*Objects[i]);

			if (Enemy* e = dynamic_cast<Enemy*>(Objects[i])) {

				e->UpDifficulty();
				if (!(e->active) && inc > 0) {
					e->active = true;
					inc--;
				}


			}

			if (O.speed > 3)
			{
				if (rand() % 5 == 0)
				{
					O.speed--;
				}
				out++;
			}
		}
		if (out == 0) {
			Objects[0]->speed++;
		}
		times--;
	}
	
}

void Game::Init() {
	char initials[3];
	bool done;
	cout << "_____________________\nA V O I D  the B A D D I E S!!!\n";
	do//name segment
	{
		done = true;
		cout << "\nPlease enter two initials for your player: \n";
		cin.getline(initials, 3, '\n');
		Initials = initials;
		if (initials[0] == NULL || initials[1] == NULL || cin.fail()) {
			done = false;
			cin.clear();
			cin.ignore(1000, '\n');
		}
		else {

		}
	} while (!done);
	firsti = initials[0];
	lasti = initials[1];

	cin.clear();
	Console::Clear();
	


}