#pragma once

#include "stdafx.h"
#include "Player.h"

Player::Player() {
	hp = 1;
	score = 0;
	speed = 12;
}

Player::~Player() {

}

void Player::Update() {
	active = true;
	type = 1;
	Base::Update();
	SetCol(ConsoleColor::Cyan);
	/*
	hatecpp.rar
	int xaxis = GetAsyncKeyState(VK_RIGHT) - GetAsyncKeyState(VK_LEFT);
	int yaxis = GetAsyncKeyState(VK_DOWN) - GetAsyncKeyState(VK_UP);

	x += signbit((float) xaxis);
	y += signbit((float) yaxis);
	*/
	bool rkey, lkey, ukey, dkey;
	rkey = GetAsyncKeyState(VK_RIGHT);
	lkey = GetAsyncKeyState(VK_LEFT);
	ukey = GetAsyncKeyState(VK_UP);
	dkey = GetAsyncKeyState(VK_DOWN);
	if (delay % speed == 0)
	{
		if (rkey) {
			x++;
		}
		else if (lkey) {
			x--;
		}

		if (dkey) {
			y++;
		}
		else if (ukey) {
			y--;
		}
	}

	//score += (float)(0.1);

	if (GetCol() != ConsoleColor::Cyan) {
		if (seq > 20) {
			seq = 0;
		}elseif(seq == 10) {
			SetCol(ConsoleColor::Blue);
		}elseif(seq == 20) {
			SetCol(ConsoleColor::Cyan);
		}
	}
}

#if 0
class Player : public Base {
	void Update() {
		active = true;
		type = 1;
		Base::Update();
		/*
		hatecpp.rar
		int xaxis = GetAsyncKeyState(VK_RIGHT) - GetAsyncKeyState(VK_LEFT);
		int yaxis = GetAsyncKeyState(VK_DOWN) - GetAsyncKeyState(VK_UP);

		x += signbit((float) xaxis);
		y += signbit((float) yaxis);
		*/
		bool rkey, lkey, ukey, dkey;
		rkey = GetAsyncKeyState(VK_RIGHT);
		lkey = GetAsyncKeyState(VK_LEFT);
		ukey = GetAsyncKeyState(VK_UP);
		dkey = GetAsyncKeyState(VK_DOWN);
		if (delay % speed == 0)
		{
			if (rkey) {
				x++;
			}
			else if (lkey) {
				x--;
			}

			if (dkey) {
				y++;
			}
			else if (ukey) {
				y--;
			}
		}

		//score += (float)(0.1);

		if (GetCol() != ConsoleColor::Cyan) {
			if (seq > 20) {
				seq = 0;
			}elseif(seq == 10) {
				SetCol(ConsoleColor::Blue);
			}elseif(seq == 20) {
				SetCol(ConsoleColor::Cyan);
			}
		}
	}
private:
	float lifetime = 0;

};
#endif