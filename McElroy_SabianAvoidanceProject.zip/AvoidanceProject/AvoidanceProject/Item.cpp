#pragma once

#include "stdafx.h"
#include "Item.h"

Item::Item()
{
	active = true;
	type = 3;
	seq = 0;
}
Item::Item(int t)
{
	if (t == 3)
		SetCol(ConsoleColor::Yellow);
	if (t == 4)
		SetCol(ConsoleColor::Red);
	active = true;
	type = t;
	seq = 0;
}

Item::~Item()
{
}

void Item::Update() {
	seq++;
	if (type == 3)
	{
		switch (seq % 8)
		{
		case 0:

			SetSym('\\');
			break;
		case 1:
			SetSym('-');
			break;
		case 2:
			SetSym('/');
			break;
		case 3:
			SetSym('-');
			break;
		default:
			break;
		}
	}
	elseif(type == 4) {
		switch (seq % 6)
		{
		case 0:

			SetSym('0');
			break;
		case 1:
			SetSym(')');
			break;
		case 2:
			SetSym('O');
			break;
		case 3:
			SetSym('(');
			break;
		default:
			break;
		}
	}
}