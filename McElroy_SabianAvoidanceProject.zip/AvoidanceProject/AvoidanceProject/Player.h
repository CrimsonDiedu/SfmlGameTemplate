#pragma once

#include "Base.h"

class Player : public Base
{
public:
	Player();
	~Player();

	void Update();
private:
	float lifetime = 0;
};