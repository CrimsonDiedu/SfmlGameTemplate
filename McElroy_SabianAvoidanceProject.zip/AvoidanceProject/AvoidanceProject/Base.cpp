#pragma once

#include "stdafx.h"
#include "Base.h"

Base::Base() {
	sym = 'm';
	c = ConsoleColor::White;
	speed = 0;
	type = 0;
	interacted = false;
	active = false;
}

Base::~Base() {

}

void Base::SetObj(int px, int py, int s) {
	x = px;
	y = py;
	speed = s;
}

void Base::SetCol(ConsoleColor col) {
	c = col;
}

ConsoleColor Base::GetCol() {
	return c;
}

void Base::Move(int px, int py) {

}

void Base::Hurt() {
	hp--;
}

void Base::Heal(int h) {
	hp += h;
}

void Base::Rpos() {
	x = rand() % Console::WindowWidth();
	y = rand() % Console::WindowHeight();
}

int Base::GetX() {
	return x;
}

int Base::GetY() {
	return y;
}

int Base::GetHP() {
	return hp;
}

int Base::GetScore() {
	return (int)score;
}

void Base::Update() {
	xp = x;
	yp = y;
	delay++;
	seq++;
	interacted = false;
}

void Base::Render() {
	if (active)
	{
		Console::Lock(true);
		if (x < 1) { x = Console::WindowWidth() - 1; }
		if (x > Console::WindowWidth() - 1) { x = 1; }
		if (y < 4) { y = Console::WindowHeight() - 1; }
		if (y > Console::WindowHeight() - 1) { y = 4; }

		if (x > 0 && x < Console::WindowWidth() &&
			y > 0 && y < Console::WindowHeight())
		{
			int xx = Console::CursorLeft(), yy = Console::CursorTop();
			Console::SetCursorPosition(x, y);
			Console::ForegroundColor(c);
			cout << sym;

			if (xp != x || yp != y) {
				Console::SetCursorPosition(xp, yp);
				cout << ' ';
			}
			Console::Lock(false);
			//Console::SetCursorPosition(xx, yy);
			Console::ResetColor;
		}
	}
	else {
		Console::SetCursorPosition(xp, yp);
		cout << ' ';
	}
}

bool Base::Alive() {
	return (hp > 0);
}

void Base::SetSym(char c) {
	sym = c;
}

void Base::AddPoints(int p) {
	score += p;
}

void Base::SetType(int t) {
	type = t;
}
