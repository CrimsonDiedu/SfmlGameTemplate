#pragma once


class BW
{
public:
	

private:
    BW();
	~BW();
};

BW::BW()
{
}

BW::~BW()
{
}