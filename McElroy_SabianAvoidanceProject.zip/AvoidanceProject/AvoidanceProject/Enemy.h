#pragma once

#include "Base.h"

class Enemy : public Base
{
public:
	Enemy();
	~Enemy();

	void Move(int px, int py);
	void Update();
	void UpDifficulty();

private:
	int pause = 0, seq = 0, chance = 3;
};


